function main() {
    console.log(
        "That's right, twenty five years into the future. I've always dreamed on seeing the future, looking beyond my years, seeing the progress of mankind. I'll also be able to see who wins the next twenty-five world series."
    );
}

window.onload(main);
